DIR=/usr/lib/linux-u-boot-edge-beaglev-ahead



